<?php
defined('_JEXEC') or die();

class JElementVmStates extends JElement {

    /**
     * Element name
     * @access  protected
     * @var     string
     */
    var $_name = 'states';

    function fetchElement($name, $value, &$node, $control_name) {

        $db =  JFactory::getDBO();

        $query = 'SELECT `virtuemart_state_id` AS value, `state_name` AS text FROM `#__virtuemart_states`
                    WHERE `virtuemart_country_id` = 110 ORDER BY `state_name` ASC '
        ;

        $db->setQuery($query);
        $fields = $db->loadObjectList();
        $class = ($node->attributes('class') ? 'class="' . $node->attributes('class') . '"' : '');


        $class = 'multiple="true" size="10"  ';
        return JHTML::_('select.genericlist', $fields, $control_name . '[' . $name . '][]', $class, 'value', 'text', $value, $control_name . $name);
    }

}