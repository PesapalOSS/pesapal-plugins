<?php
/**
 *
 * Pesapal payment plugin
 *
 * @author Lazaro Ong'ele
 * @package VirtueMart
 * @subpackage payment
 * Copyright (C) 2015 PesaPal Team. All rights reserved.
 * @license http://www.gnu.org/copyleft/gpl.html GNU/GPL, see LICENSE.php
 * VirtueMart is free software. This version may have been modified pursuant
 * to the GNU General Public License, and as distributed it includes or
 * is derivative of works licensed under the GNU General Public License or
 * other free or open source software licenses.
 * See /administrator/components/com_virtuemart/COPYRIGHT.php for copyright notices and details.
 *
 * http://virtuemart.net
 */

if ($viewData['isMobile'] ) {
    $width="100%";
    $height="100%";
} else {
	$width="100%";
	$height="700px";
}
$browserbar= 'Make Payment';
$document = JFactory::getDocument();
$document->setTitle($browserbar);

?>

<style type="text/css">
    .vm-order-done h3{ display: none!important}
</style>

<iframe src="<?php echo $viewData['url'] ?>" width="<?php echo $width ?>" height="<?php echo $height ?>"  scrolling="true" frameBorder="0">
    <p>Browser unable to load iFrame</p>
</iframe>
