<?php
/**
 *
 * Pesapal payment plugin
 *
 * @author Lazaro Ong'ele
 * @package VirtueMart
 * @subpackage payment
 * Copyright (C) 2015 PesaPal Team. All rights reserved.
 * @license http://www.gnu.org/copyleft/gpl.html GNU/GPL, see LICENSE.php
 * VirtueMart is free software. This version may have been modified pursuant
 * to the GNU General Public License, and as distributed it includes or
 * is derivative of works licensed under the GNU General Public License or
 * other free or open source software licenses.
 * See /administrator/components/com_virtuemart/COPYRIGHT.php for copyright notices and details.
 *
 * http://virtuemart.net
 */

defined('_JEXEC') or die('Restricted access');
if (!class_exists('vmPSPlugin')) {
	require(JPATH_VM_PLUGINS . DS . 'vmpsplugin.php');
}

if (!class_exists('OAuthSignatureMethod_HMAC_SHA1')) {
	require(VMPATH_ROOT .DS.'plugins'.DS.'vmpayment'.DS.'pesapal'.DS.'pesapal'.DS.'helpers'.DS.'OAuth.php');
}


class plgVmPaymentPesapal extends vmPSPlugin {

	function __construct(& $subject, $config) {

		//if (self::$_this)
		//   return self::$_this;
		parent::__construct($subject, $config);
		
		
		$this->_loggable = TRUE;
		$this->tableFields = array_keys($this->getTableSQLFields());
		$this->_tablepkey = 'id'; //virtuemart_pesapal_id';
		$this->_tableId = 'id'; //'virtuemart_pesapal_id';
		$varsToPush = array(
			'pesapalproduct' => array('', 'char'),
			'live_consumer_key' => array('', 'char'),
			'live_consumer_secret' => array('', 'char'),
			'sandbox' => array(0, 'int'),
			'sandbox_consumer_key' => array('', 'char'),
			'sandbox_consumer_secret' => array('', 'char'),
			'status_pending' => array('', 'char'),
			'status_success' => array('', 'char'),
			'status_canceled' => array('', 'char'),
		);

		$this->setConfigParameterable($this->_configTableFieldName, $varsToPush);
		//self::$_this = $this;
		
		vmJsApi::addJScript( '/plugins/vmpayment/pesapal/pesapal/assets/js/admin.js');
		vmJsApi::css('pesapal', 'plugins/vmpayment/pesapal/pesapal/assets/css/');
	}

	public function getVmPluginCreateTableSQL() {
		return $this->createTableSQL('PesaPal Table');
	}

	function getTableSQLFields() {

		$SQLfields = array(
			'id' => 'int(11) UNSIGNED NOT null AUTO_INCREMENT',
			'virtuemart_order_id' => 'int(1) UNSIGNED',
			'order_number' => 'char(64)',
			'virtuemart_paymentmethod_id' => 'mediumint(1) UNSIGNED',
			'payment_name' => 'varchar(5000)',
			'payment_order_total' => 'decimal(15,5) NOT null',
			'payment_currency' => 'smallint(1)',
			'email_currency' => 'smallint(1)',
			'cost_per_transaction' => 'decimal(10,2)',
			'cost_percent_total' => 'decimal(10,2)',
			'tax_id' => 'smallint(1)',
			'pesapal_custom' => 'varchar(255) ',
		);
		return $SQLfields;
	}

	/**
	 * @param $product
	 * @param $productDisplay
	 * @return bool
	 */
	function plgVmOnProductDisplayPayment($product, &$productDisplay) {
		return;
		$vendorId = 1;
		if ($this->getPluginMethods($vendorId) === 0) {
			return FALSE;
		}

		return TRUE;
	}

	/**
	 * @param VirtuemartViewUser $user
	 * @param                    $html
	 * @param bool               $from_cart
	 * @return bool|null
	 */
	function plgVmDisplayLogin(VirtuemartViewUser $user, &$html, $from_cart = FALSE) {

		// only to display it in the cart, not in list orders view
		if (!$from_cart) {
			return null;
		}

		$vendorId = 1;
		if (!class_exists('VirtueMartCart')) {
			require(VMPATH_SITE . DS . 'helpers' . DS . 'cart.php');
		}

		$cart = VirtueMartCart::getCart();
		if ($this->getPluginMethods($cart->vendorId) === 0) {
			return FALSE;
		}

		if (!($selectedMethod = $this->getVmPluginMethod($cart->virtuemart_paymentmethod_id))) {
			return FALSE;
		}

		return;

	}

	/**
	 * @param $cart
	 * @param $payment_advertise
	 * @return bool|null
	 */
	function plgVmOnCheckoutAdvertise($cart, &$payment_advertise) {

		if ($this->getPluginMethods($cart->vendorId) === 0) {
			return FALSE;
		}
		if (!($selectedMethod = $this->getVmPluginMethod($cart->virtuemart_paymentmethod_id))) {
			return null;
		}
		if (isset($cart->cartPrices['salesPrice']) && $cart->cartPrices['salesPrice'] <= 0.0) {
			return null;
		}

		return;
	}
	


	/**
	 *
	 * @param $cart
	 * @param $order
	 * @return bool|null|void
	 */
	function plgVmConfirmedOrder($cart, $order) {
		
		$document = JFactory::getDocument();
		$document->addScriptDeclaration('
		    document.title = "Make Payment";
		');

		if (!($this->_currentMethod = $this->getVmPluginMethod($order['details']['BT']->virtuemart_paymentmethod_id))) {
			return null; // Another method was selected, do nothing
		}
		if (!$this->selectedThisElement($this->_currentMethod->payment_element)) {
			return FALSE;
		}

		if (!class_exists('VirtueMartModelOrders')) {
			require(VMPATH_ADMIN . DS . 'models' . DS . 'orders.php');
		}
		if (!class_exists('VirtueMartModelCurrency')) {
			require(VMPATH_ADMIN . DS . 'models' . DS . 'currency.php');
		}
		$html='';
		$this->getPaymentCurrency($this->_currentMethod);
		$email_currency = $this->getEmailCurrency($this->_currentMethod);

		$payment_name = $this->renderPluginName($this->_currentMethod, $order);

		$this->debugLog('order number: ' . $order['details']['BT']->order_number, 'plgVmConfirmedOrder', 'message');
		$this->setCart($cart);
		$this->setOrder($order);
		$this->setTotal($order['details']['BT']->order_total);
		
		


		// Prepare data that should be stored in the database
		$dbValues['order_number'] = $order['details']['BT']->order_number;
		$dbValues['payment_name'] = $payment_name;
		$dbValues['virtuemart_paymentmethod_id'] = $cart->virtuemart_paymentmethod_id;
		//$dbValues['pesapal_custom'] = $this->getContext();
		$dbValues['cost_per_transaction'] = $this->_currentMethod->cost_per_transaction;
		$dbValues['cost_percent_total'] = $this->_currentMethod->cost_percent_total;
		$dbValues['payment_currency'] = $this->_currentMethod->payment_currency;
		$dbValues['email_currency'] = $email_currency;
		$dbValues['payment_order_total'] = $this->getTotal();
		$dbValues['tax_id'] = $this->_currentMethod->tax_id;
		$this->storePSPluginInternalData($dbValues);
		VmConfig::loadJLang('com_virtuemart_orders', TRUE);
		
		$this->_method = $this->getPluginMethod($cart->virtuemart_paymentmethod_id);
		if ($this->_currentMethod->published) {
			
			//Set the credentials
			$this->payment_desc = ($this->_method->payment_desc) ? $this->_method->payment_desc : 'VitueMart Payment';
			if ($this->_method->sandbox) {
				$this->api_link 	= 'http://demo.pesapal.com';
				$this->consumer_key 	= $this->_method->sandbox_consumer_key;
				$this->consumer_secret	= $this->_method->sandbox_consumer_secret;
				if (empty($this->consumer_key)) {
					$sandbox = "";
					if ($this->_method->sandbox) {
						$sandbox = 'SANDBOX_';
					}
					$text = vmText::sprintf('VMPAYMENT_PESAPAL_PARAMETER_REQUIRED', vmText::_('VMPAYMENT_PESAPAL_' . $sandbox . 'CONSUMER_KEY'), $this->_method->payment_name, $this->_method->virtuemart_paymentmethod_id);
					vmError($text, $text);
					return FALSE;
				}
				if (empty($this->consumer_secret)) {
					$sandbox = "";
					if ($this->_method->sandbox) {
						$sandbox = 'SANDBOX_';
					}
					$text = vmText::sprintf('VMPAYMENT_PESAPAL_PARAMETER_REQUIRED', vmText::_('VMPAYMENT_PESAPAL_' . $sandbox . 'CONSUMER_SECRET'), $this->_method->payment_name, $this->_method->virtuemart_paymentmethod_id);
					vmError($text, $text);
					return FALSE;
				}
			} else {
				$this->api_link 		= 'https://www.pesapal.com';
				$this->consumer_key 	= $this->_method->live_consumer_key;
				$this->consumer_secret	= $this->_method->live_consumer_secret;
				if (empty($this->consumer_key)) {
					$live = "";
					if ($this->_method->sandbox) {
						$live = 'LIVE_';
					}
					$text = vmText::sprintf('VMPAYMENT_PESAPAL_PARAMETER_REQUIRED', vmText::_('VMPAYMENT_PESAPAL_' . $live . 'CONSUMER_KEY'), $this->_method->payment_name, $this->_method->virtuemart_paymentmethod_id);
					vmError($text, $text);
					return FALSE;
				}
				if (empty($this->consumer_secret)) {
					$live = "";
					if ($this->_method->sandbox) {
						$live = 'LIVE_';
					}
					$text = vmText::sprintf('VMPAYMENT_PESAPAL_PARAMETER_REQUIRED', vmText::_('VMPAYMENT_PESAPAL_' . $live . 'CONSUMER_SECRET'), $this->_method->payment_name, $this->_method->virtuemart_paymentmethod_id);
					vmError($text, $text);
					return FALSE;
				}	
			}
			
			$this->consumer_key 	= str_replace(' ','',$this->consumer_key);
			$this->consumer_secret	= str_replace(' ','',$this->consumer_secret);
		}
		
		
		$token = $params 	= null;
		$iframelink 		= $this->api_link.'/api/PostPesapalDirectOrderV4';
		$signature_method	= new OAuthSignatureMethod_HMAC_SHA1();
		$consumer 		= new OAuthConsumer($this->consumer_key, $this->consumer_secret); 
		$amount 		= str_replace(',','',$dbValues['payment_order_total']); // remove thousands seperator if included
		$amount 		= number_format($amount, 2); //format amount to 2 decimal places
		$desc 			= $this->payment_desc;
		$type 			= 'MERCHANT';	
		$first_name 		= $order['details']['BT']->first_name;
		$last_name 		= $order['details']['BT']->last_name;
		$email 			= $order['details']['BT']->email;
		$phonenumber		= ($order['details']['BT']->phone_1) ? $order['details']['BT']->phone_1 : $order['details']['BT']->phone_2;
		$currency 		= shopFunctions::getCurrencyByID($this->_currentMethod->payment_currency, 'currency_code_3');;
		$reference 		= $dbValues['order_number']; //unique transaction id, generated by merchant.
		$callback_url 		= 'http://localhost/pesapalPHPExample/redirect.php'; //URL user to be redirected to after payment
		$callback_url 		= JROUTE::_ (JURI::root () . 'index.php?option=com_virtuemart&view=pluginresponse&task=pluginresponsereceived');
			
		$post_xml	= "<?xml version=\"1.0\" encoding=\"utf-8\"?>
					<PesapalDirectOrderInfo 
						xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" 
						xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" 
						Currency=\"".$currency."\" 
						Amount=\"".$amount."\" 
						Description=\"".$desc."\" 
						Type=\"".$type."\" 
						Reference=\"".$reference."\" 
						FirstName=\"".$first_name."\" 
						LastName=\"".$last_name."\" 
						Email=\"".$email."\" 
						PhoneNumber=\"".$phonenumber."\" 
						xmlns=\"http://www.pesapal.com\" />";
		$post_xml = htmlentities($post_xml);
		
		//post transaction to pesapal
		$iframe_src = OAuthRequest::from_consumer_and_token($consumer, $token, "GET", $iframelink, $params);
		$iframe_src->set_parameter("oauth_callback", $callback_url);
		$iframe_src->set_parameter("pesapal_request_data", $post_xml);
		$iframe_src->sign_request($signature_method, $consumer, $token);
		
		if ($this->_currentMethod->pesapalproduct == 'hosted') {
			//$this->ManageCheckout();
			jimport('joomla.environment.browser');
			$browser = JBrowser::getInstance();

			// this code is only called incase of iframe (templateD), in all other cases redirecttopayapl has been done
			$html = $this->renderByLayout('hostediframe', array("url" => $iframe_src,
				"isMobile" => $browser->isMobile()
			));
				
			// 2 = don't delete the cart, don't send email and don't redirect
			$cart->_confirmDone = FALSE;
			$cart->_dataValidated = FALSE;
			$cart->setCartIntoSession();
			vRequest::setVar('html', $html);
		} else if($this->_currentMethod->pesapalproduct == 'api'){
			$app = JFactory::getApplication();
			$app->redirect($iframe_src);
		} else{
			vmError('Unknown Pesapal mode');
		}
	}


	/**
	 * @param $virtuemart_paymentmethod_id
	 * @param $paymentCurrencyId
	 * @return bool|null
	 */
	function plgVmgetPaymentCurrency($virtuemart_paymentmethod_id, &$paymentCurrencyId) {

		if (!($this->_currentMethod = $this->getVmPluginMethod($virtuemart_paymentmethod_id))) {
			return null; // Another method was selected, do nothing
		}
		if (!$this->selectedThisElement($this->_currentMethod->payment_element)) {
			return FALSE;
		}
		$this->getPaymentCurrency($this->_currentMethod);
		$paymentCurrencyId = $this->_currentMethod->payment_currency;
	}

	/**
	 * @param $html
	 * @return bool|null|string
	 */
	function plgVmOnPaymentResponseReceived(&$html) {

		if (!class_exists('VirtueMartCart')) {
			require(VMPATH_SITE . DS . 'helpers' . DS . 'cart.php');
		}
		if (!class_exists('VirtueMartModelOrders')) {
			require(VMPATH_ADMIN . DS . 'models' . DS . 'orders.php');
		}
		VmConfig::loadJLang('com_virtuemart_orders', TRUE);
		
		$app 			= JFactory::getApplication();
		$order_number 		= vRequest::getString('pesapal_merchant_reference', '');
		$pesapalTrackingId	= vRequest::getString('pesapal_transaction_tracking_id', '');
		
		if (!($virtuemart_order_id = VirtueMartModelOrders::getOrderIdByOrderNumber ($order_number))) {
			return;
		}
		
		if (!count($order_pass_payment_method_id = $this->getOrderPassAndPaymentMethodId($order_number))) {
			return '';
		}
		
		$virtuemart_paymentmethod_id	= $order_pass_payment_method_id->virtuemart_paymentmethod_id;
		$order_pass			= $order_pass_payment_method_id->order_pass;

		if (!($this->_currentMethod = $this->getVmPluginMethod($virtuemart_paymentmethod_id))) {
			return null; // Another method was selected, do nothing
		}
		
		if (!$this->selectedThisElement($this->_currentMethod->payment_element)) {
			return null;
		}
		
		//check Payment Status
		if($this->_currentMethod->sandbox==1){
			$api 			= 'http://demo.pesapal.com';
			$consumer_key 		= $this->_currentMethod->sandbox_consumer_key; 
			$consumer_secret 	= $this->_currentMethod->sandbox_consumer_secret; 
		}else{
			$api = 'https://www.pesapal.com';
			$consumer_key 		= $this->_currentMethod->live_consumer_key; 
			$consumer_secret 	= $this->_currentMethod->live_consumer_secret; 
		}
			
		$this->QueryPaymentStatus 		= $api.'/API/QueryPaymentStatus';
		$this->QueryPaymentStatusByMerchantRef	= $api.'/API/QueryPaymentStatusByMerchantRef';
		$this->querypaymentdetails 		= $api.'/API/querypaymentdetails';
		$this->token = $this->params		= null;
		$this->signature_method			= new OAuthSignatureMethod_HMAC_SHA1();
		$this->consumer 			= new OAuthConsumer($consumer_key, $consumer_secret);
		
	
		$order 			= array();
		$modelOrder 		= VmModel::getModel ('orders');
		$vmorder 		= $modelOrder->getOrder ($virtuemart_order_id);
		$transaction_details 	= $this->getTransactionDetails($order_number, $pesapalTrackingId);
	
		if ($transaction_details['status'] == 'COMPLETED') {
			$order['customer_notified'] 	= 0;
			$order['order_status'] 		= $this->_currentMethod->status_success;
			$order['comments'] 		= vmText::sprintf ('VMPAYMENT_PESAPAL_PAYMENT_STATUS_CONFIRMED', $order_number);
		}else if($transaction_details['status'] == 'FAILED') {
			$order['customer_notified'] 	= 0;
			$order['order_status'] 		= $this->_currentMethod->status_canceled;
			$order['comments'] 		= vmText::sprintf ('VMPAYMENT_PESAPAL_PAYMENT_STATUS_CANCELED', $order_number);
		}else if($transaction_details['status'] == 'PENDING') {
			$order['customer_notified'] 	= 0;
			$order['order_status'] 		= $this->_currentMethod->status_pending;
			$order['comments'] 		= vmText::sprintf ('VMPAYMENT_PESAPAL_PAYMENT_STATUS_PENDING', $order_number);
		}else {
			$order['customer_notified'] 	= 0;
			$order['comments'] 		= vmText::sprintf ('VMPAYMENT_PESAPAL_ERROR_TRY_AGAIN', $order_number);
			$order['order_status'] 		= $this->_currentMethod->status_pending;
		}
		
		$this->logInfo ('plgVmOnPaymentNotification return new_status:' . $order['order_status'], 'message');
		
		$DBUpdated = $modelOrder->updateStatusForOneOrder ($virtuemart_order_id, $order, TRUE);
		
		//We delete the old stuff
		//get the correct cart / session
		$cart = VirtueMartCart::getCart();
		$cart->emptyCart();
		
		if($transaction_details['status']=='PENDING'){
			$message_type = "notification";
			$message = "Your payment is being processed. You will be notified as soon as the payment is confirmed.";
		}
		else if($transaction_details['status']=='COMPLETED'){
			$message_type = "message";
			$message = "Your payment has completed successfully";
		}
		else if($transaction_details['status']=='FAILED'){
			$message_type = "error";
			$message = "Your payment has failed. Please contact Pesapal Help-desk on <a href='http://support.pesapal.com'>http://support.pesapal.com</a> for more details.";
		}
		else{
			$message_type = "notification";
			$message = "Sorry, there seems to be a technical issue (Invalid Payment Status). Please contact us for assistance.";
		}
		
		$order_details_link = JRoute::_('index.php?option=com_virtuemart&view=orders&layout=details&order_number='.$order_number.'&order_pass='.$order_pass.'&Itemid=' . vRequest::getInt('Itemid'), false);
		$app->redirect($order_details_link, $message, $message_type);	
	}
	
	/**
	 * @param $html
	 * @return bool|null|string
	 */
	function plgVmOnPaymentNotification () {

		if (!class_exists('VirtueMartCart')) {
			require(VMPATH_SITE . DS . 'helpers' . DS . 'cart.php');
		}
		if (!class_exists('VirtueMartModelOrders')) {
			require(VMPATH_ADMIN . DS . 'models' . DS . 'orders.php');
		}
		VmConfig::loadJLang('com_virtuemart_orders', TRUE);
		
		$app 			= JFactory::getApplication();
		$order_number 		= vRequest::getString('pesapal_merchant_reference', '');
		$pesapalTrackingId	= vRequest::getString('pesapal_transaction_tracking_id', '');
		$pesapalNotification 	= vRequest::getString('pesapal_notification_type', '');
		
		if($pesapalNotification=="CHANGE"){
		
			if (!($virtuemart_order_id = VirtueMartModelOrders::getOrderIdByOrderNumber ($order_number))) {
				return;
			}
			
			if (!count($order_pass_payment_method_id = $this->getOrderPassAndPaymentMethodId($order_number))) {
				return '';
			}
			
			$virtuemart_paymentmethod_id	= $order_pass_payment_method_id->virtuemart_paymentmethod_id;
			$order_pass			= $order_pass_payment_method_id->order_pass;
	
			if (!($this->_currentMethod = $this->getVmPluginMethod($virtuemart_paymentmethod_id))) {
				return null; // Another method was selected, do nothing
			}
			
			if (!$this->selectedThisElement($this->_currentMethod->payment_element)) {
				return null;
			}
			
			//check Payment Status
			if($this->_currentMethod->sandbox==1){
				$api 			= 'http://demo.pesapal.com';
				$consumer_key 		= $this->_currentMethod->sandbox_consumer_key; 
				$consumer_secret 	= $this->_currentMethod->sandbox_consumer_secret; 
			}else{
				$api = 'https://www.pesapal.com';
				$consumer_key 		= $this->_currentMethod->live_consumer_key; 
				$consumer_secret 	= $this->_currentMethod->live_consumer_secret; 
			}
				
			$this->QueryPaymentStatus 		= $api.'/API/QueryPaymentStatus';
			$this->QueryPaymentStatusByMerchantRef	= $api.'/API/QueryPaymentStatusByMerchantRef';
			$this->querypaymentdetails 		= $api.'/API/querypaymentdetails';
			$this->token = $this->params		= null;
			$this->signature_method			= new OAuthSignatureMethod_HMAC_SHA1();
			$this->consumer 			= new OAuthConsumer($consumer_key, $consumer_secret);
			
		
			$order 			= array();
			$modelOrder 		= VmModel::getModel ('orders');
			$vmorder 		= $modelOrder->getOrder ($virtuemart_order_id);
			$transaction_details 	= $this->getTransactionDetails($order_number, $pesapalTrackingId);
		
			if ($transaction_details['status'] == 'COMPLETED') {
				$order['customer_notified'] 	= 1;
				$order['order_status'] 		= $this->_currentMethod->status_success;
				$order['comments'] 		= vmText::sprintf ('VMPAYMENT_PESAPAL_PAYMENT_STATUS_CONFIRMED', $order_number);
			}else if($transaction_details['status'] == 'FAILED') {
				$order['customer_notified'] 	= 1;
				$order['order_status'] 		= $this->_currentMethod->status_canceled;
				$order['comments'] 		= vmText::sprintf ('VMPAYMENT_PESAPAL_PAYMENT_STATUS_CANCELED', $order_number);
			}else if($transaction_details['status'] == 'PENDING') {
				$order['customer_notified'] 	= 0;
				$order['order_status'] 		= $this->_currentMethod->status_pending;
				$order['comments'] 		= vmText::sprintf ('VMPAYMENT_PESAPAL_PAYMENT_STATUS_PENDING', $order_number);
			}else {
				$order['customer_notified'] 	= 0;
				$order['comments'] 		= vmText::sprintf ('VMPAYMENT_PESAPAL_ERROR_TRY_AGAIN', $order_number);
				$order['order_status'] 		= $this->_currentMethod->status_pending;
			}
			
			$this->logInfo ('plgVmOnPaymentNotification return new_status:' . $order['order_status'], 'message');
			
			$dbUpdateSuccessful = $modelOrder->updateStatusForOneOrder ($virtuemart_order_id, $order, TRUE);
			
			//If there was a status change and you updated your db successfully && the change is not to a Pending state	
			if($dbUpdateSuccessful && $transaction_details['status']!='PENDING'){
				
				$resp	= "pesapal_notification_type=$pesapalNotification".		
						  "&pesapal_transaction_tracking_id=$pesapalTrackingId".
						  "&pesapal_merchant_reference=$order_number";
						  
				ob_start();
				echo $resp;
				ob_flush();
				exit; //this is mandatory. If you dont exit, Pesapal will not get your response.
			}
		}
	}


	private function _storePesapalInternalData( $pesapal_data, $virtuemart_order_id, $virtuemart_paymentmethod_id, $order_number) {
		// get all know columns of the table
		$db = JFactory::getDBO();
		$query = 'SHOW COLUMNS FROM `' . $this->_tablename . '` ';
		$db->setQuery($query);
		$columns = $db->loadColumn(0);

		$post_msg = '';
		
		//$response_fields = $this->storePesapalInternalData($pesapal_data);
		if (array_key_exists('PAYMENTINFO_0_PAYMENTSTATUS', $pesapal_data)) {
			$response_fields['pesapal_response_payment_status'] = $pesapal_data['PAYMENTINFO_0_PAYMENTSTATUS'];
		} else {
			if (array_key_exists('PAYMENTSTATUS', $pesapal_data)) {
				$response_fields['pesapal_response_payment_status'] = $pesapal_data['PAYMENTSTATUS'];
			} else {
				if (array_key_exists('PROFILESTATUS', $pesapal_data)) {
					$response_fields['pesapal_response_payment_status'] = $pesapal_data['PROFILESTATUS'];
				} else {
					if (array_key_exists('STATUS', $pesapal_data)) {
						$response_fields['pesapal_response_payment_status'] = $pesapal_data['STATUS'];
					}
				}
			}
		}


		if ($pesapal_data) {
			$response_fields['pesapal_fullresponse'] = json_encode($pesapal_data);
		}
		$response_fields['order_number'] = $order_number;
		if (isset($pesapal_data['invoice'])) {
			$response_fields['pesapal_response_invoice'] = $pesapal_data['invoice'];
		}

		$response_fields['virtuemart_order_id'] = $virtuemart_order_id;
		$response_fields['virtuemart_paymentmethod_id'] = $virtuemart_paymentmethod_id;
		if (array_key_exists('custom', $pesapal_data)) {
			$response_fields['pesapal_custom'] = $pesapal_data['custom'];
		}

		//$preload=true   preload the data here too preserve not updated data
		return $this->storePSPluginInternalData($response_fields, $this->_tablepkey, 0);

	}

	/**
	 * @param   int $virtuemart_order_id
	 * @param string $order_number
	 * @return mixed|string
	 */
	private function _getPesapalInternalData($virtuemart_order_id, $order_number = '') {
		if (empty($order_number)) {
			$orderModel = VmModel::getModel('orders');
			$order_number = $orderModel->getOrderNumber($virtuemart_order_id);
		}
		$db = JFactory::getDBO();
		$q = 'SELECT * FROM `' . $this->_tablename . '` WHERE ';
		$q .= " `order_number` = '" . $order_number . "'";

		$db->setQuery($q);
		if (!($payments = $db->loadObjectList())) {
			// JError::raiseWarning(500, $db->getErrorMsg());
			return '';
		}
		return $payments;
	}

	protected function renderPluginName($activeMethod) {
		$return = '';
		$plugin_name = $this->_psType . '_name';
		$plugin_desc = $this->_psType . '_desc';
		$description = '';
		// 		$params = new JParameter($plugin->$plugin_params);
		// 		$logo = $params->get($this->_psType . '_logos');
		$logosFieldName = $this->_psType . '_logos';
		$logos = $activeMethod->$logosFieldName;
		if (!empty($logos)) {
			$return = $this->displayLogos($logos) . ' ';
		}
		$pluginName = $return . '<span class="' . $this->_type . '_name">' . $activeMethod->$plugin_name . '</span>';
		if ($activeMethod->sandbox) {
			$pluginName .= ' <span style="color:red;font-weight:bold">Sandbox (' . $activeMethod->virtuemart_paymentmethod_id . ')</span>';
		}
		if (!empty($activeMethod->$plugin_desc)) {
			$pluginName .= '<span class="' . $this->_type . '_description">' . $activeMethod->$plugin_desc . '</span>';
		}
		$pluginName .= $this->displayExtraPluginNameInfo($activeMethod);
		return $pluginName;
	}

	function displayExtraPluginNameInfo($activeMethod) {
		

		return;

	}

	/**
	 * Display stored payment data for an order
	 *
	 * @see components/com_virtuemart/helpers/vmPSPlugin::plgVmOnShowOrderBEPayment()
	 */
	function plgVmOnShowOrderBEPayment($virtuemart_order_id, $payment_method_id) {

		if (!$this->selectedThisByMethodId($payment_method_id)) {
			return null; // Another method was selected, do nothing
		}
		if (!($this->_currentMethod = $this->getVmPluginMethod($payment_method_id))) {
			return FALSE;
		}
		if (!($payments = $this->_getPesapalInternalData($virtuemart_order_id))) {
			// JError::raiseWarning(500, $db->getErrorMsg());
			return '';
		}

		//$html = $this->renderByLayout('orderbepayment', array($payments, $this->_psType));
		$html = '<table class="adminlist table" >' . "\n";
		$html .= $this->getHtmlHeaderBE();
		$code = "pesapal_response_";
		$first = TRUE;
		foreach ($payments as $payment) {
			$html .= ' <tr class="row1"><td><strong>' . vmText::_('VMPAYMENT_PESAPAL_DATE') . '</strong></td><td align="left"><strong>' . $payment->created_on . '</strong></td></tr> ';
			// Now only the first entry has this data when creating the order
			if ($first) {
				$html .= $this->getHtmlRowBE('COM_VIRTUEMART_PAYMENT_NAME', $payment->payment_name);
				// keep that test to have it backwards compatible. Old version was deleting that column  when receiving an IPN notification
				if ($payment->payment_order_total and  $payment->payment_order_total != 0.00) {
					$html .= $this->getHtmlRowBE('COM_VIRTUEMART_TOTAL', $payment->payment_order_total . " " . shopFunctions::getCurrencyByID($payment->payment_currency, 'currency_code_3'));
				}

				$first = FALSE;
			} else {

				if (isset($payment->pesapal_fullresponse) and !empty($payment->pesapal_fullresponse)) {
					$pesapal_data = json_decode($payment->pesapal_fullresponse);
					$html .= $this->onShowOrderBEPayment($pesapal_data);

					$html .= '<tr><td></td><td>
    <a href="#" class="PesaPalLogOpener" rel="' . $payment->id . '" >
        <div style="background-color: white; z-index: 100; right:0; display: none; border:solid 2px; padding:10px;" class="vm-absolute" id="PesaPalLog_' . $payment->id . '">';

					foreach ($pesapal_data as $key => $value) {
						$html .= ' <b>' . $key . '</b>:&nbsp;' . $value . '<br />';
					}

					$html .= ' </div>
        <span class="icon-nofloat vmicon vmicon-16-xml"></span>&nbsp;';
					$html .= vmText::_('VMPAYMENT_PESAPAL_VIEW_TRANSACTION_LOG');
					$html .= '  </a>';
					$html .= ' </td></tr>';
				} else {
					$html .= $this->onShowOrderBEPaymentByFields($payment);
				}
			}


		}
		$html .= '</table>' . "\n";

		$doc = JFactory::getDocument();
		$js = "
	jQuery().ready(function($) {
		$('.PesaPalLogOpener').click(function() {
			var logId = $(this).attr('rel');
			$('#PesaPalLog_'+logId).toggle();
			return false;
		});
	});";
		$doc->addScriptDeclaration($js);
		return $html;

	}


	/**
	 * Check if the payment conditions are fulfilled for this payment method
	 * @param VirtueMartCart $cart
	 * @param int $activeMethod
	 * @param array $cart_prices
	 * @return bool
	 */
	protected function checkConditions($cart, $activeMethod, $cart_prices) {

		//Check method publication start
		if ($activeMethod->publishup) {
			$nowDate = JFactory::getDate();
			$publish_up = JFactory::getDate($activeMethod->publishup);
			if ($publish_up->toUnix() > $nowDate->toUnix()) {
				return FALSE;
			}
		}
		if ($activeMethod->publishdown) {
			$nowDate = JFactory::getDate();
			$publish_down = JFactory::getDate($activeMethod->publishdown);
			if ($publish_down->toUnix() <= $nowDate->toUnix()) {
				return FALSE;
			}
		}
		$this->convert_condition_amount($activeMethod);

		$address = $cart->getST();

		$amount = $this->getCartAmount($cart_prices);
		$amount_cond = ($amount >= $activeMethod->min_amount AND $amount <= $activeMethod->max_amount
			OR
			($activeMethod->min_amount <= $amount AND ($activeMethod->max_amount == 0)));

		$countries = array();
		if (!empty($activeMethod->countries)) {
			if (!is_array($activeMethod->countries)) {
				$countries[0] = $activeMethod->countries;
			} else {
				$countries = $activeMethod->countries;
			}
		}
		// probably did not gave his BT:ST address
		if (!is_array($address)) {
			$address = array();
			$address['virtuemart_country_id'] = 0;
		}

		if (!isset($address['virtuemart_country_id'])) {
			$address['virtuemart_country_id'] = 0;
		}
		if (in_array($address['virtuemart_country_id'], $countries) || count($countries) == 0) {
			if ($amount_cond) {
				return TRUE;
			}
		}

		return FALSE;
	}


	/**
	 * @param $jplugin_id
	 * @return bool|mixed
	 */
	function plgVmOnStoreInstallPaymentPluginTable($jplugin_id) {
		if ($jplugin_id != $this->_jid) {
			return FALSE;
		}
		$this->_currentMethod = $this->getPluginMethod(vRequest::getInt('virtuemart_paymentmethod_id'));
		if ($this->_currentMethod->published) {
			
			if ($this->_currentMethod->sandbox) {
				$sandbox = 'SANDBOX_';
				$sandbox_param = 'sandbox_';
				$param = $sandbox_param.'consumer_key';
					
				if (empty ($this->_currentMethod->$param)) {
					$text = vmText::sprintf('VMPAYMENT_PESAPAL_PARAMETER_REQUIRED', vmText::_('VMPAYMENT_PESAPAL_' . $sandbox . 'CONSUMER_KEY'), $this->_currentMethod->payment_name, $this->_currentMethod->virtuemart_paymentmethod_id);
					vmWarn($text);
				}
				
				$param = $sandbox_param.'consumer_secret';
				if (empty ($this->_currentMethod->$param)) {
					$text = vmText::sprintf('VMPAYMENT_PESAPAL_PARAMETER_REQUIRED', vmText::_('VMPAYMENT_PESAPAL_' . $sandbox . 'CONSUMER_SECRET'), $this->_currentMethod->payment_name, $this->_currentMethod->virtuemart_paymentmethod_id);
					vmWarn($text);
				}
					
					
			} else {
				$live = 'LIVE_';
				$live_param = 'live_';
				$param = $live_param.'consumer_key'; 
					
				if (empty ($this->_currentMethod->$param)) {
					$text = vmText::sprintf('VMPAYMENT_PESAPAL_PARAMETER_REQUIRED', vmText::_('VMPAYMENT_PESAPAL_' . $live . 'CONSUMER_KEY'), $this->_currentMethod->payment_name, $this->_currentMethod->virtuemart_paymentmethod_id);
					vmWarn($text);
				}
				
				$param = $live_param.'consumer_secret';
				if (empty ($this->_currentMethod->$param)) {
					$text = vmText::sprintf('VMPAYMENT_PESAPAL_PARAMETER_REQUIRED', vmText::_('VMPAYMENT_PESAPAL_' . $live . 'CONSUMER_SECRET'), $this->_currentMethod->payment_name, $this->_currentMethod->virtuemart_paymentmethod_id);
					vmWarn($text);
				}
			}
		}

		return $this->onStoreInstallPluginTable($jplugin_id);
	}

	/**
	 * This event is fired after the payment method has been selected. It can be used to store
	 * additional payment info in the cart.
	 *
	 * @param VirtueMartCart $cart: the actual cart
	 * @return null if the payment was not selected, true if the data is valid, error message if the data is not valid
	 *
	 */
	public function plgVmOnSelectCheckPayment (VirtueMartCart $cart,  &$msg) {

		return $this->OnSelectCheck ($cart);
	}


	/**
	 * Save updated order data to the method specific table
	 *
	 * @param array $_formData Form data
	 * @return mixed, True on success, false on failures (the rest of the save-process will be
	 * skipped!), or null when this method is not activated.

	public function plgVmOnUpdateOrderPayment(  $_formData) {
	return null;
	}
	 */


	/**
	 * plgVmDisplayListFEPayment
	 * This event is fired to display the pluginmethods in the cart (edit shipment/payment) for exampel
	 *
	 * @param object  $cart Cart object
	 * @param integer $selected ID of the method selected
	 * @return boolean True on success, false on failures, null when this plugin was not selected.
	 * On errors, JError::raiseWarning (or JError::raiseError) must be used to set a message.
	 *
	 * @author Valerie Isaksen
	 * @author Max Milbers
	 */
	public function plgVmDisplayListFEPayment (VirtueMartCart $cart, $selected = 0, &$htmlIn) {

		return $this->displayListFE ($cart, $selected, $htmlIn);
	}


	/**
	 * This event is fired during the checkout process. It can be used to validate the
	 * method data as entered by the user.
	 *
	 * @return boolean True when the data was valid, false otherwise. If the plugin is not activated, it should return null.
	 * @author Max Milbers

	public function plgVmOnCheckoutCheckDataPayment($psType, VirtueMartCart $cart) {
	return null;
	}
	 */

	

	//Calculate the price (value, tax_id) of the selected method, It is called by the calculator
	//This function does NOT to be reimplemented. If not reimplemented, then the default values from this function are taken.
	public function plgVmOnSelectedCalculatePricePayment(VirtueMartCart $cart, array &$cart_prices, &$cart_prices_name) {
		if (!($selectedMethod = $this->getVmPluginMethod($cart->virtuemart_paymentmethod_id))) {
			return FALSE;
		}
		//$this->isExpToken($selectedMethod, $cart) ;
		return $this->onSelectedCalculatePrice($cart, $cart_prices, $cart_prices_name);
	}


	/* backward compatibility */
	public function getPesapalProduct() {
		if (isset($this->_currentMethod->pesapalproduct) and !empty($this->_currentMethod->pesapalproduct)) {
			return $this->_currentMethod->pesapalproduct;
		} else {
			return 'std';
		}
	}


	// Checks how many plugins are available. If only one, the user will not have the choice. Enter edit_xxx page
	// The plugin must check first if it is the correct type
	public function plgVmOnCheckAutomaticSelectedPayment(VirtueMartCart $cart, array $cart_prices = array(), &$paymentCounter) {
		return $this->onCheckAutomaticSelected($cart, $cart_prices, $paymentCounter);
	}

	// This method is fired when showing the order details in the frontend.
	// It displays the method-specific data.
	public function plgVmOnShowOrderFEPayment($virtuemart_order_id, $virtuemart_paymentmethod_id, &$payment_name) {
		$this->onShowOrderFE($virtuemart_order_id, $virtuemart_paymentmethod_id, $payment_name);
	}

	// This method is fired when showing when priting an Order
	// It displays the the payment method-specific data.
	public function plgVmonShowOrderPrintPayment($order_number, $method_id) {
		return $this->onShowOrderPrint($order_number, $method_id);
	}

	public function plgVmDeclarePluginParamsPaymentVM3( &$data) {
		return $this->declarePluginParams('payment', $data);
	}

	public function plgVmSetOnTablePluginParamsPayment($name, $id, &$table) {
		return $this->setOnTablePluginParams($name, $id, $table);
	}
	
	public function checkStatusUsingTrackingIdandMerchantRef($pesapalMerchantReference,$pesapalTrackingId){
	
		//get transaction status
		$request_status = OAuthRequest::from_consumer_and_token(
			$this->consumer, 
			$this->token, 
			"GET", 
			$this->QueryPaymentStatus, 
			$this->params
		);
		
		$request_status->set_parameter("pesapal_merchant_reference", $pesapalMerchantReference);
		$request_status->set_parameter("pesapal_transaction_tracking_id",$pesapalTrackingId);
		$request_status->sign_request($this->signature_method, $this->consumer, $this->token);
		
		$status = $this->curlRequest($request_status);
	
		return $status;
	}
	
	public function getTransactionDetails($pesapalMerchantReference,$pesapalTrackingId){

		$request_status = OAuthRequest::from_consumer_and_token(
			$this->consumer, 
			$this->token, 
			"GET", 
			$this->querypaymentdetails, 
			$this->params
		);
		$request_status->set_parameter("pesapal_merchant_reference", $pesapalMerchantReference);
		$request_status->set_parameter("pesapal_transaction_tracking_id",$pesapalTrackingId);
		$request_status->sign_request($this->signature_method, $this->consumer, $this->token);
	
		$responseData = $this->curlRequest($request_status);
		
		$pesapalResponse = explode(",", $responseData);
		$pesapalResponseArray=array('pesapal_transaction_tracking_id'=>$pesapalResponse[0],
				   'payment_method'=>$pesapalResponse[1],
				   'status'=>$pesapalResponse[2],
				   'pesapal_merchant_reference'=>$pesapalResponse[3]);
				   
		return $pesapalResponseArray;
	}
	
	public function checkStatusByMerchantRef($pesapalMerchantReference){
	
		$request_status = OAuthRequest::from_consumer_and_token(
								$this->consumer, 
								$this->token, 
								"GET", 
								$this->QueryPaymentStatusByMerchantRef, 
								$this->params
							);
		$request_status->set_parameter("pesapal_merchant_reference", $pesapalMerchantReference);
		$request_status->sign_request($this->signature_method, $this->consumer, $this->token);
	
		$status = $this->curlRequest($request_status);
	
		return $status;
	}
	
	public function curlRequest($request_status){
		
		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL, $request_status);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
		curl_setopt($ch, CURLOPT_HEADER, 1);
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
		if(defined('CURL_PROXY_REQUIRED')) if (CURL_PROXY_REQUIRED == 'True'){
			$proxy_tunnel_flag = (
					defined('CURL_PROXY_TUNNEL_FLAG') 
					&& strtoupper(CURL_PROXY_TUNNEL_FLAG) == 'FALSE'
				) ? false : true;
			curl_setopt ($ch, CURLOPT_HTTPPROXYTUNNEL, $proxy_tunnel_flag);
			curl_setopt ($ch, CURLOPT_PROXYTYPE, CURLPROXY_HTTP);
			curl_setopt ($ch, CURLOPT_PROXY, CURL_PROXY_SERVER_DETAILS);
		}
		
		$response 					= curl_exec($ch);
		$header_size 				= curl_getinfo($ch, CURLINFO_HEADER_SIZE);
		$raw_header  				= substr($response, 0, $header_size - 4);
		$headerArray 				= explode("\r\n\r\n", $raw_header);
		$header 					= $headerArray[count($headerArray) - 1];
		
		//transaction status
		$elements = preg_split("/=/",substr($response, $header_size));
		$pesapal_response_data = $elements[1];
		
		return $pesapal_response_data;
	}
	
	function getPesapalPaymentCurrency ($getCurrency = FALSE) {
		vmPSPlugin::getPaymentCurrency($this->_method);
		$this->currency_code_3 = shopFunctions::getCurrencyByID($this->_method->payment_currency, 'currency_code_3');

	}

	public function setCart ($cart) {
		$this->cart = $cart;
		if (!isset($this->cart->cartPrices) or empty($this->cart->cartPrices)) {
			$this->cart->prepareCartData();
		}
	}

	public function setOrder ($order) {
		$this->order = $order;
	}

	public function setTotal ($total) {
		if (!class_exists('CurrencyDisplay')) {
			require(VMPATH_ADMIN . DS  .'helpers'.DS.'currencydisplay.php');
		}
		$this->total = vmPSPlugin::getAmountValueInCurrency($total, $this->_method->payment_currency);

		$cd = CurrencyDisplay::getInstance($this->cart->pricesCurrency);
	}

	public function getTotal () {
		return $this->total;
	}

	public function getOrderPassAndPaymentMethodId($order_number){
		$db = JFactory::getDBO ();
		$q = 'SELECT `order_pass`, `virtuemart_paymentmethod_id` FROM `#__virtuemart_orders` WHERE `order_number` ="'.$order_number.'" ';
		$db = JFactory::getDBO ();
		$db->setQuery ($q);

		return $db->loadObject();
	}
	
	public function paymentMethodID(){
		$db = JFactory::getDBO ();
		$q = 'SELECT `virtuemart_paymentmethod_id` FROM `#__virtuemart_paymentmethods` WHERE `payment_element` ="pesapal" ';
		$db = JFactory::getDBO ();
		$db->setQuery ($q);

		return $db->loadResult();
	}

}

// No closing tag
