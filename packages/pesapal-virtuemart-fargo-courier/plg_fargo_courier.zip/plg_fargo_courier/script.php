<?php
// No direct access to this file
defined('_JEXEC') or die('Restricted access');
 
/**
 * Script file of HelloWorld component
 */
class plgVmShipmentFargo_courierInstallerScript{
 
        /**
         * method to run after an install/update/uninstall method
         *
         * @return void
         */
        function postflight($type, $parent)  {
                // $parent is the class calling this method
                // $type is the type of change (install, update or discover_install)
				
				// create view/payment folders
				$plugin_src = JPATH_ROOT.DS.'plugins'.DS.'vmshipment'.DS.'fargo_courier';
				$vmstates_path = JPATH_ROOT.DS.'administrator'.DS.'components'.DS.'com_virtuemart'.DS.'elements';
				
				$vmstates_source = $plugin_src.DS.'vmstates.php';
				$vmstates_destination = $vmstates_path.DS.'vmstates.php';
	
				if(JFile::exists($vmstates_source)){
				   JFile::move($vmstates_source, $vmstates_destination);
				}
        }
}

?>